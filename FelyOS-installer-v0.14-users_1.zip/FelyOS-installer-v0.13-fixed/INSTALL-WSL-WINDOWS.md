# FelyOS 0.14 — Windows/WSL2 build

## 1. Install WSL yourself
Open **PowerShell as Administrator**:

```powershell
wsl --install --no-distribution
```

Restart Windows if requested. Then check:

```powershell
wsl --status
wsl --set-default-version 2
```

## 2. Install Debian

```powershell
wsl --install -d Debian
```

Start Debian once and create the Linux username/password.

## 3. Build FelyOS
Unzip this project to a normal Windows folder such as `C:\FelyOS`. Double-click `START-BUILD.bat`.

The script only checks WSL/Debian and then performs the Linux build. It does not silently install WSL.

## 4. Result
When the build succeeds, these files are copied to the real Windows Desktop:

- `FelyOS-0.14-amd64.iso`
- `FelyOS-0.14-amd64.iso.sha256`

The ISO is a real live-build hybrid ISO, not a renamed ZIP.

## 5. Test before installing
Use a VM first (recommended), then write the ISO to a USB drive with a trusted ISO-writing tool. Never select your Windows system disk in the installer.
