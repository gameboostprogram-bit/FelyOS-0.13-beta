#!/bin/sh
# Drop packages that do not exist in Debian trixie from a live-build package list,
# so one renamed/removed package can never abort the whole ISO build.
# Usage: prune-packages.sh <list-file>      (needs network to deb.debian.org; skips itself if unavailable)
LIST="$1"
[ -f "$LIST" ] || { echo "prune: no list $LIST"; exit 0; }
MIRROR="${PRUNE_MIRROR:-http://deb.debian.org/debian}"
SUITE="${PRUNE_SUITE:-trixie}"
COMP="${PRUNE_COMPONENTS:-main contrib non-free non-free-firmware}"
T="$(mktemp -d /tmp/felyos-prune.XXXXXX)"
mkdir -p "$T/state/lists/partial" "$T/cache/archives/partial"
: > "$T/status"
echo "deb [trusted=yes arch=amd64] $MIRROR $SUITE $COMP" > "$T/sources.list"
APT="-o Dir::Etc::sourcelist=$T/sources.list -o Dir::Etc::sourceparts=/dev/null -o Dir::State=$T/state -o Dir::State::status=$T/status -o Dir::Cache=$T/cache -o APT::Architecture=amd64 -o Acquire::Languages=none"
if ! apt-get $APT update >"$T/update.log" 2>&1; then
  echo "prune: cannot reach $MIRROR ($SUITE), package list left unchanged"
  rm -rf "$T"; exit 0
fi
OUT="$T/new.list"; : > "$OUT"; DROPPED=0; TOTAL=0
while IFS= read -r line || [ -n "$line" ]; do
  pkg="$(printf '%s' "$line" | sed 's/#.*//; s/[[:space:]]//g')"
  if [ -z "$pkg" ]; then printf '%s\n' "$line" >> "$OUT"; continue; fi
  TOTAL=$((TOTAL+1))
  if apt-cache $APT show "$pkg" >/dev/null 2>&1; then
    printf '%s\n' "$line" >> "$OUT"
  else
    echo "prune: WARNING package not in $SUITE, removed from list: $pkg"; DROPPED=$((DROPPED+1))
  fi
done < "$LIST"
if [ $((DROPPED*2)) -gt "$TOTAL" ]; then
  echo "prune: suspicious result ($DROPPED of $TOTAL missing) - index looks broken, list left unchanged"
else
  cp "$OUT" "$LIST"
  echo "prune: done, removed $DROPPED of $TOTAL package(s)"
fi
rm -rf "$T"
