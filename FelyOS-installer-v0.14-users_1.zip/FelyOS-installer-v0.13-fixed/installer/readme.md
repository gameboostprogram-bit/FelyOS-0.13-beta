# FelyOS installer (planned)
Steps: Welcome, Language, Keyboard, Disk, User, Time zone, Install, Reboot.
Plan: Calamares or a GTK front-end driving `debootstrap`/`live-installer`. Not in 0.1.
