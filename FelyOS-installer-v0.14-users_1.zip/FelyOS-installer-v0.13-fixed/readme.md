# FelyOS 0.14

Debian 13 (trixie, x86_64) live OS with the **GNOME** desktop (GDM autologin), Nautilus as file explorer, Wine for `.exe`/`.msi`, Steam (with Proton via Steam Play), Discord and Spotify (Flatpak, installed on first online boot), and **FelyOS Optimizer** (`fely-optimize auto|laptop|desktop|gaming|status`) with automatic laptop/PC detection.

GPU: proprietary NVIDIA driver (DKMS, 32-bit libs for Steam/Wine) and AMD (amdgpu + Mesa/RADV, firmware) are preinstalled; Intel video acceleration too. `fely-gpu` shows the active GPU and driver; hybrid laptops use PRIME offload (switcheroo-control). Trixie ships a newer NVIDIA driver: very new GPUs (e.g. RTX 50) may need trixie-backports.

**Explorer / My PC:** the dash icon "Explorer" (`fely-mypc`) lists all disks with free space; USB drives appear automatically (auto-mount, no password), click to open in Files, "Safely remove" to eject. Files copied to a drive are written to that drive. Files also has a "My PC" bookmark.

**Hardware guard:** `felyos-guard.service` powers the PC off after showing a red screen when RAM (and swap) is ~full, or the CPU reaches 100 C. Preview the screen: `fely-redscreen --test`. Status: `fely-guard --status`.

**Disk full:** `fely-guard` shows "You cant download because haven't space for disk!" (with the drive name) when any writable disk is >=99% full or has <50 MB free (checks `fely-guard --disks`). Apps' own errors (Firefox, Files) can't be intercepted.

**Gaming:** `felyos-gamewatch` switches to gaming mode automatically while a Steam/Wine game runs. Plus: Proton sysctl (`vm.max_map_count`), higher file limits, I/O schedulers per disk type, zram (zstd), GameMode and MangoHud. Steam launch option: `gamemoderun mangohud %command%`.

**Debian features, own design:** apt + Synaptic + GDebi, software sources, printing (CUPS), Bluetooth, VPN (OpenVPN/VPNC/WireGuard), firewall (ufw/gufw), GParted, disk health (SMART), backups (Timeshift/Deja Dup), LibreOffice, VLC, firmware and microcode, locales. Debian branding (`desktop-base`) is blocked; installer = Calamares with FelyOS branding ("Install FelyOS" in the dash).

**First run:** in the live system a one-time window "Welcome to FelyOS 0.14!" with **Install** opens Calamares and copies the whole system to the disk (everything is saved after reboot). "Try FelyOS without installing" closes it and it is not shown again (marker `~/.config/felyos/welcome-done`; to keep it across reboots use a persistence partition). It never appears on an installed system. Preview: `fely-welcome --force`.

**Build in the cloud (no Linux needed):** upload this project to a GitHub repository, open Actions -> "Build FelyOS ISO" -> Run workflow. The ISO appears under Artifacts (build.log is saved even on failure).

Note: Wine/Proton do not guarantee 100% of Windows programs; anti-cheat games and some drivers may not work. In Steam: Settings -> Compatibility -> enable Steam Play for all titles.

**Users and passwords (installer):** the Calamares "Users" page asks for your name, login, computer name and a password (typed twice, strength-checked; a weak password needs an explicit tick). Optional "Log in automatically". The live user `user` and its passwordless sudo are removed after install (`tools/felyos-post-install`); the new user is the administrator via `sudo`. More users later: Settings -> System -> Users.

**Saved data:** on an installed system everything lives on the disk: files, Firefox cookies, logins, history and site data (policy in `0500_felyos_userdata.chroot` disables clearing on exit), Flatpak app data. To keep an existing /home when reinstalling, choose manual partitioning and reuse the /home partition without formatting. On a Live USB, create a persistence partition (`sudo felyos-create-persistence /dev/sdX2`); the ISO boots with the `persistence` option.

## Build the ISO
On Debian/Ubuntu with internet and ~10 GB free:

    sudo ./build.sh

Output: `FelyOS-0.14-amd64.iso`. Test in VirtualBox/QEMU (`qemu-system-x86_64 -m 2G -cdrom FelyOS-0.14-amd64.iso -enable-kvm`) or write to USB with `dd`.

## Layout
- `src/python/felyos/` — `cli.py` (fely), `info.py` (fely-info), `shell.py` (welcome + terminal), `i18n.py`
- `src/cpp/` — native tools (built by chroot hook with CMake)
- `locales/` — JSON translations (en, ru; others fall back to en)
- `assets/branding/` — logo
- `assets/wallpaper/` — default FelyOS wallpaper
- `assets/icons/` — taskbar icons from [Tabler Icons](https://github.com/tabler/tabler-icons) (MIT, see `LICENSE-tabler.txt`)
- `iso/config/` — live-build package lists, hooks, skeleton/system files
- `scripts/stage.sh` — copies sources into the ISO tree (run by build.sh)
- `boot/ kernel/ installer/ system/ terminal/ apps/` — reserved for future modules

## Commands
`fely help|version|info|update|install|settings|reboot|shutdown|create-project <name> [--lang python|cpp]`, and `fely-info` for full details.
Notepad keys: Ctrl+N new, Ctrl+O open, Ctrl+S save, Ctrl+Shift+S save as.
Terminal keys: Ctrl+C / Ctrl+L (shell), Ctrl+Shift+C/V copy/paste, Ctrl+Shift+T new tab, Ctrl+Shift+W close tab.

## Security notes
- Normal user `user` with sudo, created by live-config. Its default live password is Debian's standard live-session password (`live`) — for the live ISO only; the future installer must make users set their own password.
- All `fely` subprocesses use argv lists (no shell); privileged work goes through `sudo`/APT.

## Known limits (0.14)
- Not yet test-booted by the author; first build may need small fixes (package names, VTE spawn on your Debian version).
- BIOS boot uses syslinux in the ISO; installed systems will use GRUB.
- Installer, other languages, light theme: planned.
- Wine compatibility depends on the Windows application and its required runtimes/drivers.

## Quick build on Windows (WSL2)
Unzip, double-click `START-BUILD.bat` (first run as Administrator to install Debian). It sets up WSL, installs all
dependencies, builds the ISO and puts it on your Desktop. On Linux: `sudo bash build-all.sh`.
