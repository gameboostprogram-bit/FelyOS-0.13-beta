# FelyOS 0.14 — Debian 13 Trixie

This version updates the FelyOS build base from Debian 12 Bookworm to Debian 13 Trixie.

## Changes
- Debian 13 (trixie) base
- GNOME desktop retained
- FelyOS branding and tools retained
- Wi-Fi/Ethernet, firmware, audio, Bluetooth and graphics packages retained
- Calamares installer configuration retained
- Wine/Steam/Proton gaming support retained
- ISO output: `FelyOS-0.14-amd64.iso`

## Build
On a Debian 13/Ubuntu Linux build host with internet access and sufficient free disk space:

```bash
sudo ./build.sh
```

The script uses live-build to create a real bootable hybrid ISO. It is not a ZIP-to-ISO file rename.
