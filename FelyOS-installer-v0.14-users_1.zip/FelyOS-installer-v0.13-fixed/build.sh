#!/bin/sh
# Build a real FelyOS Debian 13/Trixie live ISO.
set -eu

[ "$(id -u)" -eq 0 ] || { echo "ERROR: run as root: sudo ./build.sh"; exit 1; }
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

need_cmd() { command -v "$1" >/dev/null 2>&1 || { echo "ERROR: missing command: $1"; exit 1; }; }
need_cmd apt-get
need_cmd lb
need_cmd xorriso
need_cmd rsync
need_cmd unsquashfs
need_cmd sha256sum

# The project is explicitly Trixie. Do not silently build against another Debian release.
if [ -r /etc/os-release ]; then
  . /etc/os-release
  case "${VERSION_CODENAME:-}" in
    trixie) : ;;
    *) echo "ERROR: FelyOS 0.14 requires Debian 13 (Trixie). Detected ${PRETTY_NAME:-unknown}."; exit 1 ;;
  esac
fi

"$ROOT/scripts/stage.sh"
WORK=/var/tmp/felyos-build
rm -rf "$WORK"
mkdir -p "$WORK"
cd "$WORK"

lb config \
  --distribution trixie \
  --architectures amd64 \
  --binary-images iso-hybrid \
  --bootloaders "syslinux,grub-efi" \
  --debian-installer none \
  --archive-areas "main contrib non-free non-free-firmware" \
  --image-name felyos \
  --iso-application FelyOS \
  --iso-volume FELYOS-0.14 \
  --bootappend-live "boot=live components persistence hostname=felyos username=user"

cp -a "$ROOT/iso/config/." config/
"$ROOT/scripts/prune-packages.sh" config/package_lists/felyos_list.chroot

# Make hooks executable and validate files using their actual language.
find config/hooks -type f -name '*.chroot' -exec chmod +x {} +
find config/includes.chroot/usr/local/bin -type f -exec chmod +x {} + 2>/dev/null || true
for f in "$ROOT"/scripts/*.sh "$ROOT"/tools/*; do
  [ -f "$f" ] || continue
  case "$f" in
    *.sh) sh -n "$f" ;;
    */fely-welcome) python3 -m py_compile "$f" ;;
    *)
      if head -n1 "$f" | grep -q '^#!.*python'; then python3 -m py_compile "$f"; else sh -n "$f"; fi
      ;;
  esac
done

lb build 2>&1 | tee "$ROOT/build.log"
ISO="$(find . -maxdepth 1 -type f -name '*.iso' -print -quit)"
[ -n "$ISO" ] || { echo "ERROR: live-build finished without an ISO."; exit 1; }

OUT="$ROOT/FelyOS-0.14-amd64.iso"
cp -f "$ISO" "$OUT"
sha256sum "$OUT" | tee "$ROOT/FelyOS-0.14-amd64.iso.sha256"

# Basic ISO sanity checks. These do not replace boot-testing in a VM/real PC.
xorriso -indev "$OUT" -toc >/dev/null 2>&1 || { echo "ERROR: generated ISO failed xorriso validation."; exit 1; }
[ "$(stat -c '%s' "$OUT")" -gt 100000000 ] || { echo "ERROR: generated ISO is suspiciously small."; exit 1; }

echo "BUILD OK: $OUT"
