# FelyOS bash configuration
case $- in *i*) ;; *) return;; esac
HISTCONTROL=ignoreboth
HISTSIZE=5000
shopt -s histappend checkwinsize
PS1='\[\e[1;34m\]\u\[\e[0m\]@\[\e[1;35m\]felyos\[\e[0m\]:\[\e[1;36m\]\w\[\e[0m\]\$ '
alias ls='ls --color=auto'
alias ll='ls -lah'
[ -f /usr/share/bash-completion/bash_completion ] && . /usr/share/bash-completion/bash_completion
if [ -n "$FELYOS" ] && [ -z "$FELYOS_BANNER" ]; then
  export FELYOS_BANNER=1
  printf 'FelyOS Terminal\nVersion 0.14\n\nWelcome to FelyOS. Type info for system information.\n\n'
fi

# Python package management: Debian 13 protects the system Python by default.
# FelyOS exposes pip directly while explicitly allowing package installation for the user.
alias pip='python3 -m pip --break-system-packages'
alias pip3='python3 -m pip --break-system-packages'
