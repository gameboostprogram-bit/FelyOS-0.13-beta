# FelyOS boot and persistence

FelyOS is built as a Debian Live hybrid ISO with BIOS/SYSLINUX and UEFI/GRUB boot support.
The build uses `live-build` with `--binary-images iso-hybrid` and both `syslinux` and `grub-efi` bootloaders.

## Persistent data

The live system is built with the `persistence` kernel boot parameter. To keep changes between boots when running from USB, create a separate ext4 partition labeled `persistence` and put this file at its root:

```
/ union
```

A helper is included:

```
sudo ./scripts/create-persistence.sh /dev/sdX2
```

Replace `/dev/sdX2` with the intended persistence partition. **This formats that partition and deletes its existing data.**

When FelyOS is installed to a normal writable disk filesystem, data is persistent normally; the above setup is for Live USB operation.
