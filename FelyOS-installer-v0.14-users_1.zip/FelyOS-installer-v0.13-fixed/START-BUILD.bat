@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
title FelyOS 0.14 - WSL2 Builder

echo.
echo ================================================================
echo   FelyOS 0.14 - Debian 13 / Trixie ISO Builder
echo ================================================================
echo.
echo WSL2 and Debian must be installed by you first.
echo.

where wsl.exe >nul 2>&1
if errorlevel 1 (
  echo ERROR: WSL is not installed.
  echo Open PowerShell as Administrator and run:
  echo   wsl --install --no-distribution
  echo Then restart Windows and install Debian:
  echo   wsl --install -d Debian
  echo.
  pause
  exit /b 1
)

wsl.exe --status >nul 2>&1
if errorlevel 1 (
  echo ERROR: WSL2 is not ready.
  echo Run in PowerShell as Administrator:
  echo   wsl --install --no-distribution
  echo.
  pause
  exit /b 1
)

wsl.exe -l -q | findstr /x /i "Debian" >nul
if errorlevel 1 (
  echo ERROR: Debian distribution was not found.
  echo Install it with:
  echo   wsl --install -d Debian
  echo Complete Debian's first-run setup, then run this file again.
  echo.
  pause
  exit /b 1
)

rem Convert the Windows project folder to a WSL path before invoking bash.
set "PROJECT=%~dp0"
for /f "delims=" %%P in ('wsl.exe -d Debian -- wslpath -a "%PROJECT%"') do set "WSL_PROJECT=%%P"
if not defined WSL_PROJECT (
  echo ERROR: Could not convert the project path to WSL format.
  echo Move the project to a simple path such as C:\FelyOS and retry.
  echo.
  pause
  exit /b 1
)

rem Only create a WSL resource file when the user has none.
if not exist "%USERPROFILE%\.wslconfig" (
  >"%USERPROFILE%\.wslconfig" echo [wsl2]
  >>"%USERPROFILE%\.wslconfig" echo memory=6GB
  >>"%USERPROFILE%\.wslconfig" echo processors=4
  >>"%USERPROFILE%\.wslconfig" echo swap=8GB
  wsl.exe --shutdown
)

echo.
echo Starting the build inside Debian WSL2...
echo The ISO will be copied to the real Windows Desktop when complete.
echo.

wsl.exe -d Debian -u root -- bash -lc "cd '%WSL_PROJECT%' && bash ./build-all.sh"
set "ERR=%ERRORLEVEL%"

echo.
if not "%ERR%"=="0" (
  echo BUILD FAILED. Read build.log in the FelyOS project folder or terminal output.
) else (
  echo BUILD COMPLETE. Check your Windows Desktop for FelyOS-0.14-amd64.iso
)
echo.
pause
exit /b %ERR%
