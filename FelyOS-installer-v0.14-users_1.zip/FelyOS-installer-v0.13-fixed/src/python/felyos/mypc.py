"""FelyOS Explorer: 'My PC' view with all drives (internal disks and USB sticks)."""
import subprocess
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gio, GLib, Gdk

CSS = b"""
window { background: #1b1d23; }
.title { font-size: 20px; font-weight: bold; color: #fff; }
.sub { color: #9aa0ad; }
row { padding: 10px 14px; border-radius: 8px; margin: 3px 8px; background: #252830; color: #e8eaf0; }
row:selected { background: #34506e; }
progressbar trough { min-height: 10px; background: #3a3e4a; border-radius: 5px; }
progressbar progress { min-height: 10px; background: #4aa3ff; border-radius: 5px; }
progressbar.full progress { background: #e5484d; }
"""


def human(n):
    n = float(n)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return ("%.0f %s" % (n, u)) if u == "B" else ("%.1f %s" % (n, u))
        n /= 1024


def usage(root):
    try:
        i = root.query_filesystem_info("filesystem::size,filesystem::free", None)
        return i.get_attribute_uint64("filesystem::size"), i.get_attribute_uint64("filesystem::free")
    except GLib.Error:
        return 0, 0


class MyPC(Gtk.Window):
    def __init__(self):
        super().__init__(title="Explorer - My PC")
        self.set_default_size(560, 520)
        self._pending = 0
        prov = Gtk.CssProvider()
        prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.add(box)
        head = Gtk.Box(spacing=8, margin=14)
        t = Gtk.Label(label="My PC", xalign=0)
        t.get_style_context().add_class("title")
        head.pack_start(t, True, True, 0)
        b = Gtk.Button(label="Open files")
        b.connect("clicked", lambda *_: self.open_uri("file://" + GLib.get_home_dir()))
        head.pack_end(b, False, False, 0)
        box.pack_start(head, False, False, 0)
        sub = Gtk.Label(label="Devices and drives. Plug in a USB drive and it appears here.", xalign=0, margin_left=14)
        sub.get_style_context().add_class("sub")
        box.pack_start(sub, False, False, 0)

        sc = Gtk.ScrolledWindow(vexpand=True)
        self.list = Gtk.ListBox()
        self.list.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.list.connect("row-activated", self.on_activate)
        sc.add(self.list)
        box.pack_start(sc, True, True, 0)

        self.mon = Gio.VolumeMonitor.get()
        for sig in ("volume-added", "volume-removed", "volume-changed", "mount-added",
                    "mount-removed", "mount-changed", "drive-connected", "drive-disconnected"):
            self.mon.connect(sig, self.schedule)
        GLib.timeout_add_seconds(5, self.tick)
        self.refresh()

    def tick(self):
        self.refresh()
        return True

    def schedule(self, *_):
        if not self._pending:
            self._pending = GLib.timeout_add(400, self._do)

    def _do(self):
        self._pending = 0
        self.refresh()
        return False

    def open_uri(self, uri):
        try:
            subprocess.Popen(["nautilus", "--new-window", uri])
        except FileNotFoundError:
            Gio.AppInfo.launch_default_for_uri(uri, None)

    def add_row(self, name, icon, root, obj, removable=False):
        row = Gtk.ListBoxRow()
        row.obj, row.root, row.removable = obj, root, removable
        h = Gtk.Box(spacing=12)
        h.pack_start(Gtk.Image.new_from_gicon(icon, Gtk.IconSize.DIALOG), False, False, 0)
        v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        n = Gtk.Label(label=name, xalign=0)
        v.pack_start(n, False, False, 0)
        if root is not None:
            size, free = usage(root)
            if size:
                bar = Gtk.ProgressBar(fraction=(size - free) / size)
                if free / size < 0.1:
                    bar.get_style_context().add_class("full")
                v.pack_start(bar, False, False, 0)
                s = Gtk.Label(label="%s free of %s" % (human(free), human(size)), xalign=0)
                s.get_style_context().add_class("sub")
                v.pack_start(s, False, False, 0)
        else:
            s = Gtk.Label(label="Not mounted - click to open", xalign=0)
            s.get_style_context().add_class("sub")
            v.pack_start(s, False, False, 0)
        h.pack_start(v, True, True, 0)
        if removable:
            e = Gtk.Button(label="Safely remove")
            e.connect("clicked", lambda *_: self.eject(obj))
            h.pack_end(e, False, False, 0)
        row.add(h)
        self.list.add(row)

    def refresh(self):
        sel = None
        for r in self.list.get_children():
            self.list.remove(r)
        self.add_row("FelyOS (system)", Gio.ThemedIcon.new("drive-harddisk"), Gio.File.new_for_path("/"), None)
        seen = set()
        for vol in self.mon.get_volumes():
            m = vol.get_mount()
            drive = vol.get_drive()
            removable = bool(drive and (drive.is_removable() or drive.can_eject()))
            root = m.get_root() if m else None
            if root is not None:
                seen.add(root.get_path())
            self.add_row(vol.get_name(), vol.get_icon(), root, vol, removable)
        for m in self.mon.get_mounts():
            if m.get_volume() is None and not m.is_shadowed():
                self.add_row(m.get_name(), m.get_icon(), m.get_root(), m, True)
        self.list.show_all()

    def on_activate(self, _lb, row):
        obj = row.obj
        if obj is None:
            self.open_uri("file:///")
        elif isinstance(obj, Gio.Volume):
            m = obj.get_mount()
            if m:
                self.open_uri(m.get_root().get_uri())
            else:
                obj.mount(Gio.MountMountFlags.NONE, Gtk.MountOperation.new(self), None, self.after_mount)
        else:
            self.open_uri(obj.get_root().get_uri())

    def after_mount(self, vol, res):
        try:
            vol.mount_finish(res)
        except GLib.Error as e:
            d = Gtk.MessageDialog(self, 0, Gtk.MessageType.ERROR, Gtk.ButtonsType.OK, "Cannot open drive")
            d.format_secondary_text(e.message)
            d.run()
            d.destroy()
            return
        m = vol.get_mount()
        if m:
            self.open_uri(m.get_root().get_uri())
        self.refresh()

    def eject(self, obj):
        op = Gtk.MountOperation.new(self)
        if isinstance(obj, Gio.Volume) and obj.can_eject():
            obj.eject_with_operation(Gio.MountUnmountFlags.NONE, op, None, lambda o, r: (o.eject_with_operation_finish(r), self.refresh()))
        else:
            m = obj.get_mount() if isinstance(obj, Gio.Volume) else obj
            if m:
                m.unmount_with_operation(Gio.MountUnmountFlags.NONE, op, None, lambda o, r: (o.unmount_with_operation_finish(r), self.refresh()))


def main():
    w = MyPC()
    w.connect("destroy", Gtk.main_quit)
    w.show_all()
    Gtk.main()
