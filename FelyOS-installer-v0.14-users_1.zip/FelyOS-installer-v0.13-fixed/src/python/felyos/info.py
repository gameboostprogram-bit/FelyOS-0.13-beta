"""FelyOS system information command."""
import os
import platform
import re
import shutil
import socket
import subprocess

from .i18n import t


def _read(path, default=""):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return default


def _cmd(argv, default="unknown"):
    try:
        p = subprocess.run(argv, text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           check=False, timeout=3)
        return p.stdout.strip() or default
    except (OSError, subprocess.SubprocessError):
        return default


def version():
    for path in ("/etc/felyos-release", "/usr/share/felyos/felyos-release"):
        for line in _read(path).splitlines():
            if line.startswith("VERSION="):
                return line.split("=", 1)[1].strip()
    return "0.14"


def debian_release():
    text = _read("/etc/os-release")
    for line in text.splitlines():
        if line.startswith("VERSION_CODENAME="):
            return line.split("=", 1)[1].strip()
    return "trixie"


def cpu():
    for line in _read("/proc/cpuinfo").splitlines():
        if line.lower().startswith("model name"):
            return line.split(":", 1)[1].strip()
    return platform.processor() or "unknown"


def gpu():
    out = _cmd(["lspci", "-mm", "-nn"], "")
    for line in out.splitlines():
        if '"VGA compatible controller"' in line or '"3D controller"' in line or '"Display controller"' in line:
            parts = re.findall(r'"([^"]*)"', line)
            if len(parts) >= 3:
                return parts[2]
            return line.split(": ", 1)[-1]
    return _cmd(["sh", "-c", 'for f in /sys/class/drm/card*/device/vendor; do [ -r "$f" ] && cat "$f"; done'], "unknown")


def _kib(field):
    for line in _read("/proc/meminfo").splitlines():
        if line.startswith(field + ":"):
            return int(line.split()[1])
    return 0


def _ram_type():
    out = _cmd(["dmidecode", "-t", "memory"], "")
    for line in out.splitlines():
        if line.strip().startswith("Type:"):
            value = line.split(":", 1)[1].strip()
            if value and value.lower() not in {"unknown", "other"}:
                return value
    return "unknown"


def ram():
    total = _kib("MemTotal")
    if not total:
        return "unknown"
    return "%s, %.1f GiB" % (_ram_type(), total / 1024 / 1024)


def storage(path="/"):
    u = shutil.disk_usage(path)
    return "%.1f GiB / %.1f GiB" % (u.used / 1024**3, u.total / 1024**3)


def short():
    return [
        ("FelyOS by FeriuxStudio", None),
        ("Base", "Debian 13 trixie"),
        ("Version", version()),
        ("CPU", cpu()),
        ("GPU", gpu()),
        ("RAM", ram()),
        ("Disk", storage()),
    ]


def full():
    rows = short()
    rows += [
        ("Kernel", platform.release()),
        ("Architecture", platform.machine()),
        ("Hostname", socket.gethostname()),
    ]
    return rows


def render(rows):
    out = []
    for i, (key, value) in enumerate(rows):
        if value is None:
            out.append(key)
        else:
            out.append(f"{key}:{value}")
        if i == 2:
            out.append("=" * 31)
    if len(rows) > 3:
        out.append("=" * 31)
    return "\n".join(out)


def main():
    print(render(full()))
