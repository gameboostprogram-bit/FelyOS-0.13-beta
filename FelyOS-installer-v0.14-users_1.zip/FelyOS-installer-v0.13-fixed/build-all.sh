#!/bin/bash
# FelyOS Windows/WSL2 builder. WSL + Debian must be installed by the user first.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "ERROR: run as root inside Debian WSL: sudo bash build-all.sh"; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"

if ! grep -q 'VERSION_CODENAME=trixie' /etc/os-release; then
  echo "ERROR: FelyOS 0.14 requires Debian 13 (Trixie) inside WSL2."
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
export TZ=Etc/UTC

echo "==> Updating package lists"
apt-get update

echo "==> Installing build dependencies"
apt-get install -y --no-install-recommends \
  live-build debootstrap debian-archive-keyring xorriso squashfs-tools \
  syslinux syslinux-common isolinux grub-efi-amd64-bin grub-pc-bin \
  mtools dosfstools rsync ca-certificates curl wget git file \
  cmake g++ make python3 unzip p7zip-full

echo "==> Copying project off /mnt/c for reliable Linux permissions and speed"
WORK=/var/tmp/felyos-src
rm -rf "$WORK"
mkdir -p "$WORK"
rsync -a --delete --exclude '*.iso' --exclude 'build.log' "$SRC/" "$WORK/"
cd "$WORK"

# Windows editors commonly create CRLF files. Normalize scripts before executing them.
find . -type f \( -name '*.sh' -o -path './tools/*' -o -path './iso/config/hooks/*' \) -exec sed -i 's/\r$//' {} +
chmod +x build.sh scripts/*.sh tools/* 2>/dev/null || true
find iso/config/hooks iso/config/includes.chroot/etc/skel/.local/share/nautilus/scripts -type f -exec chmod +x {} + 2>/dev/null || true

./build.sh
ISO="$WORK/FelyOS-0.14-amd64.iso"
[ -f "$ISO" ] || { echo "ERROR: ISO not found: $ISO"; exit 1; }

# Find the real Windows Desktop, including OneDrive/Desktop redirection.
DESKTOP_WIN="$(powershell.exe -NoProfile -NonInteractive -Command '[Environment]::GetFolderPath("Desktop")' 2>/dev/null | tr -d '\r' | head -n1 || true)"
if [ -n "$DESKTOP_WIN" ]; then
  DEST="$(wslpath -u "$DESKTOP_WIN")"
  mkdir -p "$DEST"
  cp -f "$ISO" "$DEST/FelyOS-0.14-amd64.iso"
  cp -f "$ISO.sha256" "$DEST/FelyOS-0.14-amd64.iso.sha256"
  echo "DESKTOP: $DEST/FelyOS-0.14-amd64.iso"
else
  echo "WARNING: could not resolve Windows Desktop. ISO remains at: $ISO"
fi

# Also leave a copy beside the source project if it is writable.
cp -f "$ISO" "$SRC/FelyOS-0.14-amd64.iso" 2>/dev/null || true
cp -f "$ISO.sha256" "$SRC/FelyOS-0.14-amd64.iso.sha256" 2>/dev/null || true

echo "DONE: FelyOS-0.14-amd64.iso"
